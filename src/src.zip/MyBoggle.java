import boggle.Board;
import boggle.Dictionary;

import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;

public class MyBoggle extends Board {

    private static final String dictionaryURI = "data/dictionary.txt";
    private static TreeSet<String> possibleWords = new TreeSet<>();
    private static final char[] alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g',
            'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
            'u', 'v', 'w', 'x', 'y', 'z'};

    private static Board board;
    private static Dictionary dict = new Dictionary(dictionaryURI);
    //this is the main dictionary into which we will load words from the txt file
    private static Dictionary gameDict = new Dictionary();
    //this is the game dictionary; when we search for words on the board they go here.

    //scoring variables
    private static int correct = 0;
    private static int incorrect = 0;
    private static int possible = 0;

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("ERROR: NO INPUT PARAMETERS");
            return;
        }
        String boardUri = args[0];

        //load board
        try {
            board = new Board(boardUri);
            board.printBoard();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //exhaustive search board for words
        gameDict = search();

        //prompt the user to enter as many words as they can find in that board
        System.out.println("Enter as many words are you can find in the board.");
        System.out.println("Type the word and hit enter. Enter 0 when finished.");
        play();
        end();
    }

    public static void play() {
        Scanner sc = new Scanner(System.in);
        StringBuilder input = new StringBuilder(sc.nextLine().toLowerCase());
        TreeSet<String> correctWords = new TreeSet<>();

        while (!input.toString().equals("0")) {
            if (gameDict.search(input) >= 2) {
                if (correctWords.contains(input.toString())) {
                    //already guessed
                    System.out.println("YOU ALREADY GUESSED THIS WORD");
                } else {
                    //correct word
                    System.out.println("VALID");
                    correct++;
                    correctWords.add(input.toString());
                }
            } else {
                //incorrect word
                System.out.println("INVALID");
                incorrect++;
            }
            input = new StringBuilder(sc.nextLine().toLowerCase());
        }
    }

    public static void end() {
        //after user indicates they have finished entering words
        System.out.println("Possible words");
        for (String s : possibleWords) {
            System.out.println(s);
            possible++;
        }
        System.out.printf("# of correct words: %d\n# of incorrect words: %d\n"
                + "# of possible words: %d\n", correct, incorrect, possible);
    }

    public static Dictionary search() {
        StringBuilder word = new StringBuilder("");
        Board used = new Board(); //this will keep track of whether we have used a letter or not
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if(!(board.isHasWildcard())) {
                    //~IMPORTANT~ used MUST be reset each time
                    used.clearBoard();
                    word.append(Character.toLowerCase(board.getChar(i, j)));
                    gameDict = exhaustiveSearch(i, j, used, word);
                    word.deleteCharAt(word.length()-1);
                }
                else {
                    if(board.getChar(i,j) != '*'){
                        //~IMPORTANT~ used MUST be reset each time
                        used.clearBoard();
                        word.append(Character.toLowerCase(board.getChar(i, j)));
                        gameDict = exhaustiveSearchAst(i, j, used, word);
                        word.deleteCharAt(word.length()-1);
                    }
                    else{
                       for(char c : alphabet){
                           board.setChar(i,j,c);
                           //~IMPORTANT~ used MUST be reset each time
                           used.clearBoard();
                           word.append(Character.toLowerCase(board.getChar(i, j)));
                           gameDict = exhaustiveSearchAst(i, j, used, word);
                           word.deleteCharAt(word.length()-1);
                       }
                        board.setChar(i,j,'*');
                    }
                }
            }
        }
        return gameDict;
    }

    public static Dictionary exhaustiveSearchAst(int x, int y, Board used, StringBuilder word) {

        //the arrays we'll use for the the offset (search all the surrounding cells)
        int[] xoff = {-1, 0, 1, -1, 1, -1, 0, 1};
        int[] yoff = {-1, -1, -1, 0, 0, 1, 1, 1};
        //these will function as our new coordinates
        int newx;
        int newy;
        int status;
        char next;

        //get the current character, add it to the word
        used.setChar(x,y,'1');
        //char current = board.getChar(x,y);
            //examine all the surrounding coordinates
            for (int i = 0; i < 8; i++) {
                newx = x + xoff[i];
                newy = y + yoff[i];
                //three part check:
                //make sure x is in bounds
                //make sure y is in bounds
                //make sure we haven't used this letter before
                if (((newx >= 0 && newx <= 3) && (newy >= 0 && newy <= 3)) && (used.getChar(newx, newy) == '0')) {
                    //if it's a valid coordinate, check to see if adding the letter results in a word or prefix
                    next = Character.toLowerCase(board.getChar(newx, newy));
                    if (next != '*') {
                        word.append(next);
                        //it's a word or a prefix
                        status = dict.search((word));
                        if (status > 0) {
                            //valid word, add to dictionary
                            //minimum length is 3
                            if ((status >= 2) && (word.length() >= 3)) {
                                gameDict.add(word.toString());
                                possibleWords.add(word.toString());
                            }
                            //1 or 3 means that we have a valid prefix
                            if (!(status % 2 == 0)) {
                                used.setChar(newx, newy, '1');    //mark the character as used before passing it down the stack
                                gameDict = exhaustiveSearchAst(newx, newy, used, word);
                            }
                        }
                        //to backtrack, remove the character we added and reset the character as used
                        word.deleteCharAt(word.length() - 1);
                        used.setChar(newx, newy, '0');
                    }
                    //if we are dealing with an asterisk
                    else {
                        for (char c : alphabet) {
                            word.append(c);
                            //it's a word or a prefix
                            status = dict.search((word));
                            if (status > 0) {
                                //valid word, add to dictionary
                                //minimum length is 3
                                if ((status >= 2) && (word.length() >= 3)) {
                                    gameDict.add(word.toString());
                                    possibleWords.add(word.toString());
                                }
                                //1 or 3 means that we have a valid prefix
                                if (!(status % 2 == 0)) {
                                    used.setChar(newx, newy, '1');    //mark the character as used before passing it down the stack
                                    gameDict = exhaustiveSearchAst(newx, newy, used, word);
                                }
                            }
                            //to backtrack, remove the character we added and reset the character as used
                            word.deleteCharAt(word.length() - 1);
                            used.setChar(newx, newy, '0');
                        }
                    }
                }
            }
        return gameDict;
    }

    public static Dictionary exhaustiveSearch(int x, int y, Board used, StringBuilder word) {


        //get the current character, add it to the word
        used.setChar(x,y,'1');
        //char current = board.getChar(x,y);
        char next;
        //the arrays we'll use for the the offset (search all the surrounding cells)
        int[] xoff = {-1, 0, 1,-1,1,-1,0,1};
        int[] yoff = {-1,-1,-1, 0,0, 1,1,1};
        //these will function as our new coordinates
        int newx;
        int newy;
        int status;
        //examine all the surrounding coordinates
        for (int i = 0; i < 8; i++) {
            newx = x + xoff[i];
            newy = y + yoff[i];
            //three part check:
            //make sure x is in bounds
            //make sure y is in bounds
            //make sure we haven't used this letter befpre
            if(((newx >= 0 && newx <=3)&&(newy >= 0 && newy <=3)) && (used.getChar(newx,newy) == '0')){
                //if it's a valid coordinate, check to see if adding the letter results in a word or prefix
                next = Character.toLowerCase(board.getChar(newx,newy));
                word.append(next);
                //it's a word or a prefix
                status = dict.search((word));
                if (status > 0){
                    //valid word, add to dictionary
                    //minimum length is 3
                    if ((status >= 2)&& (word.length()>=3)){
                        gameDict.add(word.toString());
                        possibleWords.add(word.toString());
                    }
                    //1 or 3 means that we have a valid prefix
                    if (!(status % 2 ==0)){
                        used.setChar(newx,newy,'1');    //mark the character as used before passing it down the stack
                        gameDict = exhaustiveSearch(newx,newy,used,word);
                    }
                }
                //to backtrack, remove the character we added and reset the character as used
                word.deleteCharAt(word.length()-1);
                used.setChar(newx,newy,'0');
            }
        }
        return gameDict;

    }
}
