import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Board {

    private char[][] boardArray;
    private boolean hasWildcard;

    public Board() {
        this.boardArray = new char[4][4];
    }

    public Board(String uri) throws IOException {
        this.boardArray = new char[4][4];
        File boardFile = new File(uri);
        FileReader reader = new FileReader(boardFile);
        char[] letters = new char[((int) boardFile.length())];
        reader.read(letters);
        loadBoard(letters);
        reader.close();
    }

    public void clearBoard() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                boardArray[i][j] = '0';
            }
        }
    }

    public char getChar(int x, int y) {
        return boardArray[x][y];
    }

    public void setChar(int x, int y, char input) {
        boardArray[x][y] = input;
    }

    public void printBoard() {
        System.out.println("_________________");
        for (int i = 0; i < 4; i++) {
            System.out.print("| ");
            for (int j = 0; j < 4; j++) {
                System.out.print(boardArray[i][j]);
                System.out.print(" | ");
            }
            System.out.print("\n");
        }
        System.out.println("_________________");
    }

    public void loadBoard(char[] inputBoard) {
        hasWildcard = false;
        int i = 0;
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                if (inputBoard[i] == '*') {
                    hasWildcard = true;
                }
                boardArray[j][k] = inputBoard[i];
                i++;
            }
        }
    }

    public boolean isHasWildcard() {
        return hasWildcard;
    }
}
